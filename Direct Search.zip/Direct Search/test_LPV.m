close all
clear
clc

A=@(rho,alpha) [0 1.2 rho(1);0 -0.1 1.2;alpha(1) rho(2)+alpha(2) alpha(3)+5];


DesignSpaceCorners=100*[1 0 0;0 1 0;0 0 1;-1 -1 -1];
ParameterSpaceCorners=10*[-1 -1;-1 1;1 -1;1 1];
ParameterDerivativeSpaceCorners=1*[-1 -1;-1 1;1 -1;1 1];
Verbose=0;
MaximumIteration=1e3;

[f,ds]=LPV(A,DesignSpaceCorners,ParameterSpaceCorners,ParameterDerivativeSpaceCorners,Verbose,MaximumIteration);
f


