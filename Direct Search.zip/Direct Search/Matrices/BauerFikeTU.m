function ef=BauerFikeTU(Ms)
ef=0;
r=length(Ms);n=length(Ms{1});
M=zeros(n);
for i=1:r
    if max(real(eig(Ms{i})))<=0
        return
    end
    M=M+Ms{i};
end
M=M/r;
m=max(real(eig(M)));
if m<0
    return
end
k=cond(M);
d=0;
for i=1:r
    d=max(d,norm(Ms{i}-M));
end
if d*k<=m
    ef=1;
end
end