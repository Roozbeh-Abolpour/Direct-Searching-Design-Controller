function ef=normTU(Ms)
ef=0;
r=length(Ms);n=length(Ms{1});
for i=1:r
    if max(real(eig(Ms{i})))<=0
        return
    end
end
M=zeros(n);
for i=1:r
    M=M+Ms{i};
end
M=M/r;Lm=kronsum(M);
Lminv=Lm\eye(size(Lm));
a=1/norm(Lminv);
d=0;
for i=1:r
    L=kronsum(Ms{i});
    d=max(d,norm(L-Lm));
end
if d<a
    ef=1;
end
end