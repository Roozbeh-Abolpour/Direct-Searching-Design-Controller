function L=kronsum(A)
n=length(A);I=eye(n);
L=.5*(kron(A,I)+kron(I,A));
end