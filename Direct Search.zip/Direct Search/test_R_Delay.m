close all
clear
clc

As{1}=[1 0;0 2];As{2}=[1.1 0;0 2];
Bs{1}=[1;2];Bs{2}=[1;2];
Ads{1}=[0.1 0;0 0];Ads{2}=[-0.1 0;0 0];

MaximumDelay=10;MaximumDelayDerivative=0.1;
DesignSpaceCorners=100*[1 0;0 1;-1 -1];
Verbose=0;MaximumIteration=1e3;

[f,ds]=R_Delay(As,Ads,Bs,MaximumDelay,MaximumDelayDerivative,DesignSpaceCorners,Verbose,MaximumIteration);
f




