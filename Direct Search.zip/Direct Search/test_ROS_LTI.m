close all
clear
clc

A=@(u) [-2 1+u(1);0.2 -1+10*u(2)];
B=@(u) [1;0];
C=@(u) [0 1];
Bw=@(u) [0;1];
Cz=@(u) [1 0];
Dzw=@(u) 1;
Ac=@(f) [-f(1) -f(2);1 0];
Bc=@(f) [1;-1];
Cc=@(f) [f(3) 1];
Dc=@(f) 0;


DesignSpaceCorners=100*[1 0 0;0 1 0;0 0 1;-1 -1 -1];
UncertainSpaceCorners=.1*[0 0;+1 0;0 +1;+1 +1];
UncertainVertexNumber=10;
Verbose=0;
MaximumIteration=1e3;
DesiredPerformance=1e-2;

[f,ds]=ROS_LTI(A,B,Bw,C,Cz,Dzw,Ac,Bc,Cc,Dc,DesignSpaceCorners,UncertainSpaceCorners,UncertainVertexNumber,Verbose,DesiredPerformance,MaximumIteration);
min(ds.DesignPointPerformances)
f