function ef=ROS_LTI_isF(md,f)
A=md.A;B=md.B;C=md.C;
Ac=md.Ac;Bc=md.Bc;
Cc=md.Cc;Dc=md.Dc;
Vu=md.Vu;Eu=md.Eu;
ef=1;
if ~isempty(Ac)
    Ace=Ac(f);Bce=Bc(f);
    Cce=Cc(f);Dce=Dc(f);
    nc=length(Ace);
else
    Dce=Dc(f);
    nc=0;
end
n=length(A(Vu(1,:)));
for i=1:size(Eu,1)
    e=Eu(i,:);
    Ve=Vu(e,:);
    setlmis([])
    P=lmivar(1,[n+nc,1]);
    ind=1;
    lmiterm([ind 1 1 P],-1,1);
    lmiterm([ind 1 1 0],1e-4*eye(n+nc));
    ind=ind+1;
    for j=1:size(Ve,1)
        Ae=A(Ve(j,:));Be=B(Ve(j,:));Ce=C(Ve(j,:));
        if ~isempty(Ac)
            Acl=[Ae+Be*Dce*Ce Be*Cce;...
                Bce*Ce Ace];
        else
            Acl=Ae+Be*Dce*Ce;
        end
        lmiterm([ind 1 1 P],Acl',1,'s');ind=ind+1;
    end
    LMI=getlmis();
    t=feasp(LMI,[0 0 0 0 1]);
    if t>0
        ef=0;
        return
    end
end
end