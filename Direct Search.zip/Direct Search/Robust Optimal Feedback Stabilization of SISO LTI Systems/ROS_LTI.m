function [f,ds]=ROS_LTI(A,B,Bw,C,Cz,Dzw,Ac,Bc,Cc,Dc,DesignSpaceCorners,UncertainSpaceCorners,UncertainVertexNumber,Verbose,DesiredPerformance,MaximumIteration)
U=UncertainSpaceCorners;
N=UncertainVertexNumber;
[V,E]=meshpolygonspace(U,N);

md.A=A;md.B=B;md.C=C;
md.Bw=Bw;md.Cz=Cz;
md.Dzw=Dzw;
md.Ac=Ac;md.Bc=Bc;
md.Cc=Cc;md.Dc=Dc;
md.U=U;md.Vu=V;md.Eu=E;

fptr1=@(md,f) ROS_LTI_isF(md,f);
fptr2=@(md,F) ROS_LTI_isTU(md,F);
fptr3=@(md,f) ROS_LTI_fp(md,f);
fptr4=@(md,F) ROS_LTI_mpb(md,F);

D=DesignSpaceCorners;
dp=DesiredPerformance;
ps.Verbose=Verbose;
v0=myvol(D);Nmax=MaximumIteration;
vm=v0/Nmax;
ps.MinimumAllowableVolume=vm;
ds=DS(md,fptr1,fptr2,fptr3,fptr4,D,dp,ps);
while ds.Feasible==0&&length(ds.Simplexes)>=1
    ds=DSstep(ds);  
    [ds.Iteration  min(ds.DesignPointPerformances)]
end
[co,ind]=min(ds.DesignPointPerformances);
if co<inf
    f=ds.DesignPoints(ind,:);
else
    f=[];
end
end