function g=ROS_LTI_mpb(md,F)
A=md.A;B=md.B;C=md.C;
Bw=md.Bw;Cz=md.Cz;
Dzw=md.Dzw;
Ac=md.Ac;Bc=md.Bc;
Cc=md.Cc;Dc=md.Dc;
Vu=md.Vu;g=-inf;
u=randpoint(Vu);
if ~isempty(Ac)
    nc=length(Ac(F(1,:)));
else
    nc=0;
end
n=length(A(u));
Ae=A(u);Be=B(u);
Ce=C(u);Bwe=Bw(u);
Bwe=[Bwe;zeros(nc,size(Bwe,2))];
Cze=Cz(u);
Cze=[Cze zeros(size(Cze,1),nc)];
Dzwe=Dzw(u);
if abs(Dzwe)<1e-8
    return
end
setlmis([])
X=lmivar(1,[n+nc,1]);
gv=lmivar(1,[1 1]);

ind=1;
lmiterm([ind 1 1 X],-1,1);
lmiterm([ind 1 1 0],1e-4*eye(n+nc));
ind=ind+1;

for i=1:size(F,1)
    f=F(i,:);
    if ~isempty(Ac)
        Ace=Ac(f);Bce=Bc(f);
        Cce=Cc(f);Dce=Dc(f);
        Acl=[Ae+Be*Dce*Ce Be*Cce;...
            Bce*Ce Ace];
    else
        Dce=Dc(f);
        Acl=Ae+Be*Dce*Ce;
    end
    if max(real(eig(Acl)))>0
        return
    end
    Dinv=1/Dzwe;
    Ainv=Acl-(Bwe*Dinv)*Cze;
    lmiterm([ind 1 1 X],Ainv',1,'s');
    lmiterm([ind 1 2 X],1,Bwe*Dinv);
    lmiterm([ind 1 3 0],-Dinv*Cze');
    lmiterm([ind 2 3 0],Dinv);
    lmiterm([ind 2 2 gv],-1,1);
    lmiterm([ind 3 3 gv],-1,1);
    ind=ind+1;
end
LMI=getlmis();
[co,q]=mincx(LMI,[zeros(1,(n+nc)*(n+nc+1)/2) 1],[0 0 0 0 1]);
if ~isempty(q)
    g=1/co;
end
end