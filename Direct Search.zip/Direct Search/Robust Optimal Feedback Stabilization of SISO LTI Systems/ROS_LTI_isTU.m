function ef=ROS_LTI_isTU(md,F)
A=md.A;B=md.B;C=md.C;
Ac=md.Ac;Bc=md.Bc;
Cc=md.Cc;Dc=md.Dc;
Vu=md.Vu;
ef=0;

u=randpoint(Vu);
Ae=A(u);Be=B(u);Ce=C(u);
ps=cell(1,size(F,1));
for j=1:size(F,1)
    if ~isempty(Ac)
        Ace=Ac(F(j,:));Bce=Bc(F(j,:));
        Cce=Cc(F(j,:));Dce=Dc(F(j,:));
        Acl=[Ae+Be*Dce*Ce Be*Cce;...
            Bce*Ce Ace];
    else
        Dce=Dc(F(j,:));
        Acl=Ae+Be*Dce*Ce;
    end
    ps{j}=poly(Acl);
end
if signTNH(ps)>0
    ef=1;
    return
elseif exposedTNH(ps)>0
    ef=1;
    return
elseif decompTNH(ps)>0
    ef=1;
    return
end

end