function ef=polyderTNH(ps)
for i=1:length(ps)
    ps{i}=polyder(ps{i});
end
ef=exposedTNH(ps)+decompTNH(ps);
ef(ef>1)=1;
end