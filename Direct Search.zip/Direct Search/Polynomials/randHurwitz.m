function p=randHurwitz(n)
A=5-10*rand(n);
m=max(real(eig(A)));
if m>0
    A=A-1.01*m*eye(n);
end
p=poly(A);
end