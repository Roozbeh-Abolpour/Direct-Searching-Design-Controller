function pr=realpart(p)
% p(s)=s^n+p(1)s^(n-1)+...
pr=fliplr([p]);
pr(2:2:end)=0;
pr(3:4:end)=-pr(3:4:end);
pr=fliplr(pr);
end