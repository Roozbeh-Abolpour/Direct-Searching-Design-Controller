function omgs=omgroots(p,q,omgm)
pr=realpart(p);
pi=imagpart(p);
qr=realpart(q);
qi=imagpart(q);

g=polyadd(conv(pr,qi),-conv(qr,pi));
omgs=roots(g);
omgs=omgs(imag(omgs)==0);
omgs(omgs<omgm)=[];
omgs=unique(omgs);
indh=[];
for i=1:length(omgs)
    pre=polyval(pr,omgs(i));
    pie=polyval(pi,omgs(i));
    qre=polyval(qr,omgs(i));
    qie=polyval(qi,omgs(i));    
    if pre*qre+qie*pie>0
        indh(end+1)=i;
    end    
end
omgs(indh)=[];
end