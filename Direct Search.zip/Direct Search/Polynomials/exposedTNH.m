function ef=exposedTNH(ps)
ef=1;
ns=zeros(1,length(ps));
for i=1:length(ps)
    rs=roots(ps{i});
    rs(real(rs)<0)=[];
    ns(i)=length(rs);
    if ns(i)==0
        ef=0;
        return
    end
end
if var(ns)~=0
    ef=0;
    return
end
for i=1:length(ps)
    for j=1:i-1
        p=ps{i};q=ps{j};
        efe=Hurwitzcritical(p,q);
        if efe==1
            ef=0;
            return
        end
    end
end
end