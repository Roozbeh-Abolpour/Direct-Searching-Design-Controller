function ef=exposedTH(ps)
ef=1;
P=[];
for i=1:length(ps)
    P=[P;ps{i}];
end
p=min(min(P));
if p<=0
    ef=0;
    return
end
ns=zeros(1,length(ps));
for i=1:length(ps)
    rs=max(real(roots(ps{i})));
    rs(real(rs)<0)=[];
    ns(i)=length(rs);
    if ns(i)>0
        ef=0;
        return
    end
end
for i=1:length(ps)
    for j=1:i-1
        p=ps{i};q=ps{j};
        efe=Hurwitzcritical(p,q);
        if efe==1
            ef=0;
            return
        end
    end
end
end