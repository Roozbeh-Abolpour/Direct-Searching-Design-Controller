function ef=homologous(fs,omgb)
ef=0;
ns=zeros(1,length(fs));
for i=1:length(fs)
    rs=roots(fs{i});
    for j=1:length(rs)
        z=rs(j);
        if real(z)>=0&&imag(z)>=omgb
            ns(i)=ns(i)+1;
        end
    end
end
if max(ns)>0&&var(ns)~=0
    return
end
for i=1:length(fs)
    for j=1:i-1
        f1=fs{i};f2=fs{j};
        ws=omgroots(f1,f2,omgb);
        ss=sigroots(f1,f2,omgb);
        if ~isempty(ws)||~isempty(ss)            
            return
        end
    end
end
if max(ns)==0
    ef=+1;
elseif var(ns)==0
    ef=-1;
end
end