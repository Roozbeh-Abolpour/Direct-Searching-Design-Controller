function sigs=sigroots(p,q,omgm)
p=polyshift(p,1i*omgm);
q=polyshift(q,1i*omgm);

pr=real(p);
pi=imag(p);
qr=real(q);
qi=imag(q);

g=polyadd(conv(pr,qi),-conv(qr,pi));
sigs=roots(g);
sigs=sigs(imag(sigs)==0);
sigs(sigs<0)=[];
sigs=unique(sigs);
indh=[];
for i=1:length(sigs)
    pre=polyval(pr,sigs(i));
    pie=polyval(pi,sigs(i));
    qre=polyval(qr,sigs(i));
    qie=polyval(qi,sigs(i));    
    if pre*qre+qie*pie>0
        indh(end+1)=i;
    end    
end
sigs(indh)=[];
end