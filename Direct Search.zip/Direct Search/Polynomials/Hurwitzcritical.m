function ef=Hurwitzcritical(p,q)
ef=0;
p=reshape(p,1,length(p));q=reshape(q,1,length(q));
pr=realpart(p);pi=imagpart(p);
qr=realpart(q);qi=imagpart(q);
z1=conv(pr,qi);z2=-conv(qr,pi);
ws=roots(polyadd(z1,z2));
ws(abs(imag(ws))>1e-8)=[];
ws(ws<0)=[];ws=unique(ws);
for i=1:length(ws)
    pre=polyval(pr,ws(i));
    pie=polyval(pi,ws(i));
    qre=polyval(qr,ws(i));
    qie=polyval(qi,ws(i));
    d=pre*qre+qie*pie;        
    if d<0
        ef=1;
        return
    end    
end
end