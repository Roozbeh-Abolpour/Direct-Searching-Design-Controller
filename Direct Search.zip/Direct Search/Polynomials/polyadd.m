function w=polyadd(p,q)
if length(p)>length(q)
    q=[zeros(1,length(p)-length(q)) q];
    w=p+q;
else
    p=[zeros(1,length(q)-length(p)) p];
    w=p+q;
end
end