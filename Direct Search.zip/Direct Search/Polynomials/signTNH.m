function ef=signTNH(ps)
ef=0;
P=[];r=length(ps);n=length(ps{1})-1;
for i=1:length(ps)
    P=[P;ps{i}];
end
p=min(max(P));
if p<=0    
    ef=1;
    return
end
end