function pi=imagpart(p)
pi=fliplr([p]);
pi(1:2:end)=0;
pi(4:4:end)=-pi(4:4:end);
pi=fliplr(pi);
end