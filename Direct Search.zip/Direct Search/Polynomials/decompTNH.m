function ef=decompTNH(ps)
ef=0;
n=length(ps{1})-1;r=length(ps);
for i=1:n-2
    pes=cell(1,r);
    for j=1:r
        pe=ps{j}(i:i+3);
        pes{j}=[pe(2) pe(1) pe(4) pe(3)];
    end
    efe=exposedTH(pes);
    if efe==1
        ef=1;
        return
    end
end
end