function ef=HadamardTNH(ps,q)
qs=ps;
for i=1:length(ps)
    qs{i}=ps{i}.*q;
end
ef=exposedTNH(qs)+polyderTNH(ps)+decompTNH(ps);
ef(ef>1)=1;
end