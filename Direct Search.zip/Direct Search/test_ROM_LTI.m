close all
clear
clc

A=@(u) [-2 1+u(1);0.2 -1+u(2)];
B=@(u) [1 0;0 1];
C=@(u) [0 1];
Bw=@(u) [0;1];
Cz=@(u) [1 0];
Dzw=@(u) 1;
Ac=[];Bc=[];Cc=[];
Dc=@(f) [f(1);f(2)];

DesignSpaceCorners=1e2*[1 0;0 1;-1 -1];
UncertainSpaceCorners=[0 0;+1 0;0 +1;+1 +1];
UncertainVertexNumber=10;
Verbose=0;
MaximumIteration=1e3;
DesiredPerformance=1e-2;

[f,ds]=ROM_LTI(A,B,Bw,C,Cz,Dzw,Ac,Bc,Cc,Dc,DesignSpaceCorners,UncertainSpaceCorners,UncertainVertexNumber,Verbose,DesiredPerformance,MaximumIteration);
min(ds.DesignPointPerformances)
f

 %save2word('report',ds.Document.Texts);
 
 
 