function ds=DSstep(ds)
ve=ds.Verbose;
Dp=ds.DesignPoints;
simp=ds.Simplexes{1};
indsimp=0;
for i=1:length(ds.GeneratedSimplexes)
    if norm(ds.GeneratedSimplexes{i}.Corners-simp.Corners)==0
        ds.GeneratedSimplexesColors(i)='b';
        indsimp=i;
    end
end
sp=ds.SaveFigurePath;
if ve==1
    disp('--------------------------------------------------------')
    disp('--------------------------------------------------------')
    disp('--------------------------------------------------------')
    ds.Document.Texts{end+1}=sprintf('Iteration %d starts.',ds.Iteration);
    disp(ds.Document.Texts{end})
    ds.Document.Texts{end+1}='The current design space has the following corner points:';
    disp(ds.Document.Texts{end})
    ds.Document.Texts{end+1}=prettytext(Dp(simp.Corners,:),'Dc');
    disp(ds.Document.Texts{end})    
    [ef,str]=showcurrentdesignspace(Dp,ds.GeneratedSimplexes,ds.GeneratedSimplexesColors,simp,indsimp,sp,ds.Document.FigureNumber,ds.Iteration);
    if ef==1
        ds.Document.Texts{end+1}='The current design space is highlighted in the following figure:';
        ds.Document.FigureNumber=ds.Document.FigureNumber+1;
        ds.Document.Texts{end+1}=['Link: ' str];
    end
    
end
mv=myvol(Dp(simp.Corners,:));
if ds.MinimumAllowableVolume>mv
    if ve==1
        ds.Document.Texts{end+1}='The volume of the current design space is smaller than the allowable volume.';
        disp(ds.Document.Texts{end})
    end
    ds.Iteration=ds.Iteration+1;
    ds.Simplexes(1)=[];
    ds.GeneratedSimplexesColors(indsimp)='y';
    return
end
md=ds.ModelData;
cptr=ds.CheckFeasibilityIndicator;
fp=ds.FindPerformance;
tui=ds.TotalUndesirabilityIndicator;
mpb=ds.MinimumPerformanceBound;
IV=simp.Corners;
if ve==1
    ds.Document.Texts{end+1}='The TU indicator  is checked and the following result is obtained:';
end
ef=tui(md,Dp(IV,:));
if ef==1
    if ve==1
        ds.Document.Texts{end+1}='The TU indicator proves the current design space is undesired.';
        disp(ds.Document.Texts{end})
    end
    ds.Iteration=ds.Iteration+1;
    ds.Simplexes(1)=[];
    ds.GeneratedSimplexesColors(indsimp)='r';
    return
end
if ve==1
    ds.Document.Texts{end+1}='The TU indicator cannot establish the current design space is undesired.';
    disp(ds.Document.Texts{end})
end

for i=1:length(IV)
    v=Dp(IV(i),:);
    if ve==1
        ds.Document.Texts{end+1}=sprintf('Corner point number %d is checked and the following result is obtained:',i);
        ds.Document.Texts{end+1}=prettytext(v,'cp');
        disp(ds.Document.Texts{end})
    end
    if ds.DesignPointResults(IV(i))~=0
        if ve==1
            ds.Document.Texts{end+1}='This point has been already checked.';
            disp(ds.Document.Texts{end})
        end
        continue
    end
    ef=cptr(md,v);
    if ef==1
        if ve==1
            ds.Document.Texts{end+1}='This point is feasible.';
            disp(ds.Document.Texts{end})
        end
        ds.DesignPointResults(IV(i))=1;
        if ~isempty(fp)
            fpe=fp(md,v);
            ds.DesignPointPerformances(IV(i))=fpe;
            
            if fpe<ds.DesiredPerformance
                ds.Iteration=ds.Iteration+1;  
                ds.Feasible=1;
                ds.Solution=v;
                return
            end
            if ve==1
                ds.Document.Texts{end+1}=sprintf('The performance of the design point is %d.',fpe);
                disp(ds.Document.Texts{end})
            end
        else
            ds.Iteration=ds.Iteration+1;
            ds.Feasible=1;
            ds.Solution=v;
            return
        end
    else
        ds.DesignPointResults(IV(i))=-1;
        if ve==1
            ds.Document.Texts{end+1}='This point is not detected to be feasible.';
            disp(ds.Document.Texts{end})
        end
    end
end
if ~isempty(mpb)
    mb=mpb(md,Dp(IV,:));    
    mp=min(ds.DesignPointPerformances);
    if mb>mp
        if ve==1
            ds.Document.Texts{end+1}='The minimum performance of the current simplex is larger than the pre-obtained minimum performance';
            disp(ds.Document.Texts{end})
        end
        ds.Iteration=ds.Iteration+1;
        ds.Simplexes(1)=[];
        return
    end
end
[simp1,simp2,Dp]=half(Dp,simp);
ds.DesignPoints=Dp;
ds.DesignPointResults(end+1)=0;
ds.DesignPointPerformances(end+1)=inf;
ds.Simplexes=[ds.Simplexes simp1 simp2];
ds.Iteration=ds.Iteration+1;
ds.Simplexes(1)=[];
ds.GeneratedSimplexes(indsimp)=[];
ds.GeneratedSimplexesColors(indsimp)=[];
ds.GeneratedSimplexes=[ds.GeneratedSimplexes simp1 simp2];
ds.GeneratedSimplexesColors=[ds.GeneratedSimplexesColors 'w' 'w'];
end