function V=cubepoints(L,U)
if length(L)==1
    V=[L;U];
    return
end
Ve=cubepoints(L(2:end),U(2:end));
ne=size(Ve,1);
V=[ones(ne,1)*L(1) Ve;...
   ones(ne,1)*U(1) Ve];
end