function simp=simplex(IV)
simp.Corners=IV;
end