function [x,q]=randpoint(V)
n=size(V,2);
L=size(V,1);
x=zeros(1,n);
q=rand(1,L);q=q/sum(q);
for i=1:L
    x=x+V(i,:)*q(i);
end
end