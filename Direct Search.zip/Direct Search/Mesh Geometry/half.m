function [simp1,simp2,V]=half(V,simp)
IV=simp.Corners;
ind1=0;ind2=0;
d=-inf;
for i=1:length(IV)
    for j=i+1:length(IV)
        if norm(V(IV(i),:)-V(IV(j),:))>d
            ind1=i;ind2=j;
            d=norm(V(IV(i),:)-V(IV(j),:));
        end
    end
end
c=.5*(V(IV(ind1),:)+V(IV(ind2),:));
V=[V;c];
IV1=IV;IV1(ind1)=size(V,1);
IV2=IV;IV2(ind2)=size(V,1);
simp1=simplex(IV1);
simp2=simplex(IV2);
end