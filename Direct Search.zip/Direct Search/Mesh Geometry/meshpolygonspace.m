function [V,E]=meshpolygonspace(U,N)
lb=size(U,1);
for i=lb+1:N
    q=rand(1,lb);q=q/sum(q);
    u=zeros(1,size(U,2));
    for j=1:lb
        u=u+q(j)*U(j,:);
    end
    U=[U;u];
end
try
    V=U;E=delaunayn(V);
catch
    V=U;E=1:size(U,1);
end
end