function v=myvol(vs)
r=size(vs,1);
M=[];
for i=1:size(vs,1)-1
    M=[M (vs(i,:)-vs(end,:))'];
end
v=abs(det(M))/factorial(r-1);
end