function ef=isinside(V,simp,v)
IV=simp.Corners;
V=V(IV,:);
T=[];
for i=1:size(V,2)
    T=[T V(i,:)'-V(end,:)'];
end
L=T\(v'-V(end,:)');
if min(L)<0||max(L)>1
    ef=0;
else
    ef=1;
end    
end