function ef=R_Delay_isF(md,f)
As=md.As;Ads=md.Ads;Bs=md.Bs;
taum=md.taum;taud=md.taud;
mu=taud;tau=taum;
N=length(As);n=length(As{1});
yalmip('clear')
Ps=cell(1,N);
Qs=cell(1,N);Rs=cell(1,N);
Ss=cell(1,N);Zs=cell(1,N);
Us=cell(1,N);Ws=cell(1,N);
Ns=cell(4,N);Ts=cell(1,5);
ep=1e-4;
F=[];
for i=1:N
    Ps{i}=sdpvar(n,n);Qs{i}=sdpvar(n,n);
    Rs{i}=sdpvar(n,n);Ss{i}=sdpvar(n,n);
    Zs{i}=sdpvar(n,n);
    Us{i}=sdpvar(n,n,'full');
    Ws{i}=sdpvar(n,n,'full');
    F=[F,Ps{i}>=ep*eye(n),Qs{i}>=ep*eye(n),...
        Rs{i}>=ep*eye(n),Ss{i}>=ep*eye(n),...
        Zs{i}>=ep*eye(n)];
end
for i=1:4
    for j=1:N
        Ns{i,j}=sdpvar(n,n,'full');
    end
end
for i=1:5
    Ts{i}=sdpvar(n,n,'full');
end
for j=1:N
    F=[F,[Qs{j} Us{j};Us{j}' Rs{j}]>=0];
    O11=Qs{j}+Ns{1,j}+Ns{1,j}'-Ts{1}*(As{j}+Bs{j}*f)-(As{j}+Bs{j}*f)'*Ts{1}'+tau*Ss{j};
    O12=Ns{2,j}'-Ns{1,j}-(As{j}+Bs{j}*f)'*Ts{2}'-Ts{1}*Ads{j};
    O13=Ps{j}+Ns{3,j}'+Ts{1}-(As{j}+Bs{j}*f)'*Ts{3}'+tau*Ws{j}+Us{j};
    O14=Ns{4,j}'-(As{j}+Bs{j}*f)'*Ts{4}';
    O22=-(1-mu)*Qs{j}-Ns{2,j}-Ns{2,j}'-Ts{2}*Ads{j}-Ads{j}'*Ts{2}';
    O23=-Ns{3,j}'+Ts{2}-Ads{j}'*Ts{3}';
    O24=-Ns{4,j}'-Ads{j}'*Ts{4}'-(1-mu)*Us{j};
    O33=tau*Zs{j}+Ts{3}+Ts{3}'+Rs{j};
    O34=Ts{4}';
    O44=-(1-mu)*Rs{j};
    Ze=zeros(size(O44,1),n);
    O15=tau*(As{j}+Bs{j}*f)'*Ts{5}';
    O16=tau*Ns{1,j};
    O25=tau*Ads{j}'*Ts{5}';O26=tau*Ns{2,j};
    O35=-tau*Ts{5};O36=tau*Ns{3,j};
    O45=Ze;O46=tau*Ns{4,j};
    O55=-tau*Ss{j};O56=-tau*Ws{j};
    O66=-tau*Zs{j};
    O=[O11 O12 O13 O14 O15 O16;...
        O12' O22 O23 O24 O25 O26;...
        O13' O23' O33 O34 O35 O36;...
        O14' O24' O34' O44 O45 O46;...
        O15' O25' O35' O45' O55 O56;...
        O16' O26' O36' O46' O56' O66];
    F=[F,O<=0];
end
od=sdpsettings;
od.solver='SDPT3';
od.verbose=0;
sol=optimize(F,[],od);
if sol.problem==0
    ef=1;
    for i=1:N
        Ps{i}=value(Ps{i});Qs{i}=value(Qs{i});
        Rs{i}=value(Rs{i});Ss{i}=value(Ss{i});
        Zs{i}=value(Zs{i});Us{i}=value(Us{i});
        Ws{i}=value(Ws{i});    
    end
    for i=1:4
        for j=1:N
            Ns{i,j}=value(Ns{i,j});
        end
    end
    for i=1:5
        Ts{i}=value(Ts{i});
    end
else
    ef=0;
end
end