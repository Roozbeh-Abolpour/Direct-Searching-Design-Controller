function ef=R_Delay_isTU(md,F)
ef=0;
As=md.As;Ads=md.Ads;Bs=md.Bs;
th=rand(1,length(As));
th=th/sum(th);
A=0;Ad=0;B=0;
for i=1:length(th)
    A=A+As{i}*th(i);
    B=B+Bs{i}*th(i);
    Ad=Ad+Ads{i}*th(i);
end
ds=cell(1,size(F,1));
for i=1:size(F,1)
    ds{i}=poly(A+Ad+B*F(i,:));
end
efe=signTNH(ds);
if efe==1
    ef=1;
    return
end
efe=decompTNH(ds);
if efe==1
    ef=1;
    return
end
efe=exposedTNH(ds);
if efe==1
    ef=1;
    return
end
taum=md.taum;

th=rand*pi;z=exp(1i*th);
ds=cell(1,size(F,1));
for j=1:length(ds)
    ds{j}=poly(A+Ad*z+B*F(j,:));
end

omgb=th/taum;
efs=1;efu=1;
for i=1:length(ds)
    rs=roots(ds{i});fl=0;
    for j=1:length(rs)
        z=rs(j);
        if real(z)>=0&&abs(imag(z))>=omgb
            efs=0;fl=1;
        end
    end
    if fl==0
        efu=0;
    end
end
efe=efs-efu;
if efe==-1&&homologous(ds,omgb)==1
    ef=1;
    return
end
end