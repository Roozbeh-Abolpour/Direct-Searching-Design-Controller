function [f,ds]=R_Delay(As,Ads,Bs,MaximumDelay,MaximumDelayDerivative,DesignSpaceCorners,Verbose,MaximumIteration)
md.As=As;md.Ads=Ads;md.Bs=Bs;
md.taum=MaximumDelay;
md.taud=MaximumDelayDerivative;

fptr1=@(md,f) R_Delay_isF(md,f);
fptr2=@(md,F) R_Delay_isTU(md,F);

D=DesignSpaceCorners;
ps.Verbose=Verbose;
v0=myvol(D);Nmax=MaximumIteration;
vm=v0/Nmax;
ps.MinimumAllowableVolume=vm;
ds=DS(md,fptr1,fptr2,[],[],D,[],ps);
while ds.Feasible==0&&length(ds.Simplexes)>=1
    ds=DSstep(ds);  
    ds.Iteration
end
f=ds.Solution;
end