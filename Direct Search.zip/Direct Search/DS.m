function ds=DS(md,cfi,tui,fp,mpb,D,dp,ps)
ve=ps.Verbose;
sp='';
ds.DesignPoints=D;
ds.Verbose=ve;
ds.SaveFigurePath=sp;
ds.DesignPointResults=zeros(1,size(D,1));
ds.DesignPointPerformances=inf*ones(1,size(D,1));
ds.MinimumAllowableVolume=ps.MinimumAllowableVolume;
D=simplex(1:size(D,1));
ds.ModelData=md;
ds.CheckFeasibilityIndicator=cfi;
ds.TotalUndesirabilityIndicator=tui;
ds.FindPerformance=fp;
ds.MinimumPerformanceBound=mpb;
ds.DesiredPerformance=dp;
ds.DesignSimplex=D;
ds.Iteration=1;
ds.Simplexes={D};
ds.GeneratedSimplexes={D};
ds.GeneratedSimplexesColors='w';
ds.Feasible=0;
ds.Solution=[];
if ve==1
    ds.Document.Texts={};
    ds.Document.FigureNumber=1;
    ds.Document.Texts{end+1}='DS starts.';
    disp(ds.Document.Texts{end})
    ds.Document.Texts{end+1}='The design space has the following corner points:';
    disp(ds.Document.Texts{end})
    ds.Document.Texts{end+1}=prettytext(ds.DesignPoints,'D');
    disp(ds.Document.Texts{end})
    
    [ef,str]=showdesignspace(ds.DesignPoints,sp,ds.Document.FigureNumber);
    if ef==1
        ds.Document.Texts{end+1}='The design space is presented by the following figure:';
        ds.Document.FigureNumber=ds.Document.FigureNumber+1;
        ds.Document.Texts{end+1}=['Link: ' str];
    end
end
end