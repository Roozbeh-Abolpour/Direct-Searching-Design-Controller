function g=ROM_LTI_fp(md,f)
A=md.A;B=md.B;C=md.C;
Bw=md.Bw;Cz=md.Cz;
Dzw=md.Dzw;
Ac=md.Ac;Bc=md.Bc;
Cc=md.Cc;Dc=md.Dc;
Vu=md.Vu;Eu=md.Eu;
if ~isempty(Ac)
    Ac=Ac(f);Bc=Bc(f);
    Cc=Cc(f);Dc=Dc(f);
    nc=length(Ac);
else
    Dc=Dc(f);nc=0;
end
n=length(A(Vu(1,:)));
g=0;
for i=1:size(Eu,1)
    e=Eu(i,:);
    Ve=Vu(e,:);
    setlmis([])
    X=lmivar(1,[n+nc,1]);
    gv=lmivar(1,[1 1]);
    ind=1;
    lmiterm([ind 1 1 X],-1,1);
    lmiterm([ind 1 1 0],1e-4*eye(n+nc));
    ind=ind+1;
    for j=1:size(Ve,1)
        Ae=A(Ve(j,:));Be=B(Ve(j,:));
        Ce=C(Ve(j,:));Bwe=Bw(Ve(j,:));
        Cze=Cz(Ve(j,:));Dzwe=Dzw(Ve(j,:));
        Bwe=[Bwe;zeros(nc,size(Bwe,2))];
        Cze=[Cze zeros(size(Cze,1),nc)];
        if ~isempty(Ac)
            Acl=[Ae+Be*Dc*Ce Be*Cc;...
                Bc*Ce Ac];
        else
            Acl=Ae+Be*Dc*Ce;
        end
        lmiterm([ind 1 1 X],Acl',1,'s');
        lmiterm([ind 1 2 X],1,Bwe);
        lmiterm([ind 1 3 0],Cze');
        lmiterm([ind 2 3 0],Dzwe);
        lmiterm([ind 2 2 gv],-1,1);
        lmiterm([ind 3 3 gv],-1,1);
        ind=ind+1;
    end
    LMI=getlmis();
    [co,q]=mincx(LMI,[zeros(1,(n+nc)*(n+nc+1)/2) 1],[0 0 0 0 1]);
    if ~isempty(q)
        ge=co;
        g=max(g,ge);
    else
        g=inf;
        return
    end
end
end