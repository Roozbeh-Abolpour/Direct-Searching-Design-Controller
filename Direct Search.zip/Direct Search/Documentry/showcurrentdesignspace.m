function [ef,str]=showcurrentdesignspace(D,as,asc,ci,ic,sp,fn,it)
V=D;
n=size(V,2);
if n>3
    ef=0;
    str='';
    return
end
ef=1;
if n==2
    figure
    hold on
    grid on
    box on    
    title(sprintf('Design Space at iteration %d',it))
    for i=1:length(as)
        if i~=ic
            Ve=V(as{i}.Corners,:);
            f=1:size(Ve,1);f=[f f(1)];
            xs=Ve(f,1);ys=Ve(f,2);
            han=fill(xs,ys,asc(i));
            set(han,'linewidth',2);
        end
    end
    Ve=V(ci.Corners,:);
    f=1:size(Ve,1);f=[f f(1)];
    xs=Ve(f,1);ys=Ve(f,2);
    han=fill(xs,ys,asc(ic));
    set(han,'linewidth',2);
    wax=axis;
    wax=wax+.1*[-1 +1 -1 +1].*abs(wax);
    axis(wax);
    set(gca,'fontname','timesnewroman')
    set(gca,'fontweight','bold')
    set(gca,'fontsize',16)
    str=sprintf([sp 'fig%d.jpg'],fn);
    saveas(gcf,str);
else
    figure
    hold on
    grid on
    box on    
    title(sprintf('Design Space at iteration %d',it))
    for i=1:length(as)
        if i~=ic&&asc(i)=='w'
            Ve=V(as{i}.Corners,:);
            fs={[1 2 3 1],[1 2 4 1],[1 3 4 1],[2 3 4 2]};
            for ii=1:length(fs)
                f=fs{ii};
                xs=Ve(f,1);ys=Ve(f,2);zs=Ve(f,3);
                han=fill3(xs,ys,zs,asc(i));
                set(han,'facealpha',0)
                set(han,'linewidth',1);
            end        
        end
    end
    for i=1:length(as)
        if i~=ic&&asc(i)~='w'
            Ve=V(as{i}.Corners,:);
            fs={[1 2 3 1],[1 2 4 1],[1 3 4 1],[2 3 4 2]};
            for ii=1:length(fs)
                f=fs{ii};
                xs=Ve(f,1);ys=Ve(f,2);zs=Ve(f,3);
                han=fill3(xs,ys,zs,asc(i));
                set(han,'facealpha',.4)
                set(han,'linewidth',1);
            end        
        end
    end
    Ve=V(ci.Corners,:);
    fs={[1 2 3 1],[1 2 4 1],[1 3 4 1],[2 3 4 2]};
    for ii=1:length(fs)
        f=fs{ii};
        xs=Ve(f,1);ys=Ve(f,2);zs=Ve(f,3);
        han=fill3(xs,ys,zs,asc(ic));
        set(han,'facealpha',.9)
        set(han,'linewidth',2);
    end
    view(24,27)
    wax=axis;
    wax=wax+.1*[-1 +1 -1 +1 -1 +1].*abs(wax);
    axis(wax);
    set(gca,'fontname','timesnewroman')
    set(gca,'fontweight','bold')
    set(gca,'fontsize',16)
    str=sprintf([sp 'fig%d.jpg'],fn);
    saveas(gcf,str);
end