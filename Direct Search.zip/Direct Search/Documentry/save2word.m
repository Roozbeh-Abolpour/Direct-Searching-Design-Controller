function save2word(name,texs)
import mlreportgen.dom.*;
d=Document(name,'docx');
for i=1:length(texs)
    ind=strfind(texs{i},'Link:');
    if ind>0
        path=texs{i}(7:end);
        I=Image(path);
        I.Height='300px';
        I.Width='400px';        
        append(d,I);
    elseif ~isempty(texs{i})
        p=Paragraph(texs{i});
        p.FontFamilyName='Times New Roman';
        p.FontSize='12pt';
        append(d,p);
    end
end
close(d);
end