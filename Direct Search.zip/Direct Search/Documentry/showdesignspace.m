function [ef,str]=showdesignspace(D,sp,fn)
V=D;
n=size(V,2);
if n>3
    ef=0;
    str='';
    return
end
ef=1;
if n==2
    figure    
    hold on
    grid on
    box on
    title('Design Space')
    f=1:size(V,1);f=[f f(1)];
    xs=V(f,1);ys=V(f,2);
    han=fill(xs,ys,'b');
    set(han,'linewidth',2);       
    wax=axis;
    wax=wax+.1*[-1 +1 -1 +1].*abs(wax);
    axis(wax);
    set(gca,'fontname','timesnewroman')
    set(gca,'fontweight','bold')
    set(gca,'fontsize',16)
    str=sprintf([sp 'fig%d.jpg'],fn);
    saveas(gcf,str);
else
    figure    
    hold on
    grid on
    box on
    title('Design Space')
    fs={[1 2 3 1],[1 2 4 1],[1 3 4 1],[2 3 4 2]};
    for ii=1:length(fs)     
        f=fs{ii};
        xs=V(f,1);ys=V(f,2);zs=V(f,3);    
        han=fill3(xs,ys,zs,'b');        
        set(han,'facealpha',.6)
        set(han,'linewidth',2)  
    end
    view(54,27)
    wax=axis;
    wax=wax+.1*[-1 +1 -1 +1 -1 +1].*abs(wax);
    axis(wax);
    set(gca,'fontname','timesnewroman')
    set(gca,'fontweight','bold')
    set(gca,'fontsize',16)
    str=sprintf([sp 'fig%d.jpg'],fn);        
    saveas(gcf,str);
end
end