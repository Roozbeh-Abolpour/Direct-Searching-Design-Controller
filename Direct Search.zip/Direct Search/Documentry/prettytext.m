function str=prettytext(A,name)
str=[name '=['];
for i=1:size(A,1)
    for j=1:size(A,2)
        if j<size(A,2)
            str=[str sprintf('%.4f ',A(i,j))];
        else
            str=[str sprintf('%.4f',A(i,j))];
        end
    end
    if i<size(A,1)
        str=[str ';'];
    end
end
str=[str ']'];
end