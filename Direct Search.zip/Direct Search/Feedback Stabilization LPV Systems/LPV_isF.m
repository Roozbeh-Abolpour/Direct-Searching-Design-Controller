function ef=LPV_isF(md,f)
A=md.A;
S0=md.ParameterSpaceCorners;
S1=md.ParameterDerivativeSpaceCorners;
Ae=A(mean(S0),f);nx=length(Ae);
r=size(S0,2);
yalmip('clear')
Consts=[];
P0=sdpvar(nx,nx);
Ps=cell(1,r);
for i=1:r
    Ps{i}=sdpvar(nx,nx);
end
for i=1:size(S0,1)
    P=P0;
    for j=1:r
        P=P+Ps{j}*S0(i,j);
    end
    Consts=[Consts,P>=1e-4*eye(nx)];
end

for i=1:size(S1,1)
    Pd=0;
    for j=1:r
        Pd=Pd+Ps{j}*S1(i,j);
    end
    for j=1:size(S0,1)
        P=P0;
        for k=1:r
            P=P+Ps{k}*S0(j,k);
        end
        for k=1:size(S0,1)
            Ae=A(S0(j,:),f);
            Consts=[Consts,P*Ae+Ae'*P+Pd<=0];
        end
    end
end
od=sdpsettings;
od.solver='SDPT3';
od.verbose=0;
sol=optimize(Consts,[],od);
if sol.problem==0
    ef=1;
else
    ef=0;
end
end