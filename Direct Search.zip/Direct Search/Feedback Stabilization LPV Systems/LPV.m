function [f,ds]=LPV(A,DesignSpaceCorners,ParameterSpaceCorners,ParameterDerivativeSpaceCorners,Verbose,MaximumIteration)

md.A=A;
md.ParameterSpaceCorners=ParameterSpaceCorners;
md.ParameterDerivativeSpaceCorners=ParameterDerivativeSpaceCorners;

fptr1=@(md,f) LPV_isF(md,f);
fptr2=@(md,F) LPV_isTU(md,F);

D=DesignSpaceCorners;
ps.Verbose=Verbose;
v0=myvol(D);Nmax=MaximumIteration;
vm=v0/Nmax;
ps.MinimumAllowableVolume=vm;
ds=DS(md,fptr1,fptr2,[],[],D,[],ps);
while ds.Feasible==0&&length(ds.Simplexes)>=1
    ds=DSstep(ds);  
    ds.Iteration
end
f=ds.Solution;
end