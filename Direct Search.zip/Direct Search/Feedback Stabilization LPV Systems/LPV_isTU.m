function ef=LPV_isTU(md,F)
A=md.A;
S0=md.ParameterSpaceCorners;
ef=0;

u=randpoint(S0);
ps=cell(1,size(F,1));
for j=1:size(F,1)
    Ae=A(u,F(j,:));
    ps{j}=poly(Ae);
end
if signTNH(ps)>0
    ef=1;
    return
elseif exposedTNH(ps)>0
    ef=1;
    return
elseif decompTNH(ps)>0
    ef=1;
    return
end

end